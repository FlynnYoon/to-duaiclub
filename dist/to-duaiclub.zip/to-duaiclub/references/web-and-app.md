# ChatGPT · Claude 웹/앱에서의 흐름 (MCP 도구)

셸이 없는 환경에서는 DUAI Club MCP 커넥터(`https://www.duaiclub.com/mcp`)의 도구를 쓴다.
커넥터 연결 시 DUAI Club 계정으로 로그인하므로 토큰이 필요 없다.

## 도구

| 도구 | 용도 |
|---|---|
| `get_active_event` | 오늘 올라갈 모임 일정 조회 |
| `upload_image` | 이미지(base64, 10MB 이하)를 올리고 `objectPath` 받기 |
| `make_card` | 제목·요약으로 결과 카드 이미지를 만들고 `objectPath` 받기 |
| `post_showcase` | 오늘 일정에 작업 결과 댓글 올리기 |

## 순서 (5분 이내)

1. **초안**: 이번 대화에서 한 일을 바탕으로 제목(40자 이내), 요약, 링크를 직접 만든다(사용자에게 쓰라고 하지 않는다). 요약은 `- `로 시작하는 3~4줄: ① 오늘 만든 것·공부한 것 ② 어떤 AI를 어떻게 썼는지 ③ 핵심 내용이나 새로 알게 된 것 ④ (선택) 막힌 점·다음 계획.
2. **일정 확인**: `get_active_event`. 일정이 없으면 사용자에게 알리고 멈춘다.
3. **이미지**:
   - 사용자가 대화에 스크린샷을 첨부했거나 코드 실행(Python 등)으로 차트·이미지를 만들었다면 그 이미지를 base64로 `upload_image`에 넘긴다.
   - 코드 실행으로 파일을 만들었지만 base64를 도구에 넘길 수 없는 환경이면 `make_card`를 쓴다.
   - 이미지가 없으면 `make_card`로 결과 카드를 만든다.
   - 기다리거나 스크린샷을 요청하지 않는다.
4. **올리기**: 묻지 않고 바로 `post_showcase`에 `title`, `summary`, `media`(`[{objectPath, kind:"image", caption}]`), `links`, `tool`("ChatGPT" 또는 "Claude")을 넘긴다. 사용자가 "올리기 전에 보여줘"라고 했을 때만 미리보기를 먼저 보여준다.
5. 결과의 `eventTitle`과 `url`, 올린 제목·요약을 알려준다.

## 주의

- 영상은 이 환경에서 올릴 수 없다. 영상이 필요하면 CLI(Claude Code, Codex)에서 `/to-duaiclub`을 쓰라고 안내한다.
- 비밀정보(API 키, 사내 기밀, 개인정보)가 담긴 이미지나 요약은 올리지 않는다.
- 도구가 `isError`를 돌려주면 메시지를 그대로 사용자에게 전하고, 입력을 고쳐 한 번만 재시도한다.
